import React from 'react';

const Plantilla = () => {
  return (
    <>
    <h1>Plantilla</h1>
    <h4>Página en creación</h4>
    </>
  );
};

export default Plantilla;