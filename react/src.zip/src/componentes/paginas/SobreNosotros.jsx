import React from 'react';

const SobreNosotros = () => {
  return (
    <>
    <h1>Sobre Nosotros</h1>
    <h4>Página en creación</h4>
    </>
  );
};

export default SobreNosotros;