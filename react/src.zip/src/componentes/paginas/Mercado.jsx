import React from 'react';

const Mercado = () => {
  return (
    <>
    <h1>Mercado</h1>
    <h4>Página en creación</h4>
    </>
  );
};

export default Mercado;