import React from 'react';

const Clasificacion = () => {
  return (
    <>
    <h1>Clasificación</h1>
    <h4>Página en creación</h4>
    </>
  );
};

export default Clasificacion;