import React from "react";

const Error = () => {
  return (
    <>
      <h1>Se ha producido un error.</h1>
      <h3>Te has ido a una página que no existe titán.</h3>
    </>
  );
};

export default Error;
